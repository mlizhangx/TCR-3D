#' TCR Summary Statistics Comparison Function
#'
#' To generate vector of descriptive statistics and p-values to compare distributions of two vectors of TCR summary statistics.
#' @param data1 Data set containing the first vector for comparison.
#' @param T1 The vector in data1 for comparison.
#' @param data2 Data set containing the second vector for comparison.
#' @param T2 The vector in data2 for comparison.
#' @param title The short title describing comparison.
#' @param paired Logical indicating whether a paired test.
#' @return Matrix with 10 or 11 columns; N1., Min1., Med1., Max1., N2., Min2., Med2., Max2., Wilcoxon, t [, NPairs].
#' @export

## fn uses a column from each of two data.frames as designated by args
## and returns matrix w descr stats for each vector & p-val for Wilcoxon signed-rank & p-val for Student's t
## and can accept arg for row title & boolean to indicate whether to do paired hypothesis tests
## USER INSTRUCT: use quotes around your value for the argument title because a name

tcr.comparison <-function(data1,T1="01",data2,T2="02",title="title",paired=FALSE){
  if(paired==FALSE){
    tbl<-t(c(length(data1[,T1][!is.na(data1[,T1])]),
             summary(data1[,T1],digits=8)[c(1,3,6)],
             length(data2[,T2][!is.na(data2[,T2])]),
             summary(data2[,T2],digits=8)[c(1,3,6)],
             wilcox.test(data1[,T1],data2[,T2],paired=FALSE)$p.value,
             t.test(data1[,T1],data2[,T2],paired=FALSE)$p.value))
    rownames(tbl)<-c(title)
    colnames(tbl)<-c(paste(c("N","Min","Med","Max"),rep(T1,4),sep="."),
                     paste(c("N","Min","Med","Max"),rep(T2,4),sep="."),"Wilcoxon","t")
    return(tbl)
  } else {
    tbl<-t(c(length(data1[,T1][!is.na(data1[,T1])]),
             summary(data1[,T1],digits=8)[c(1,3,6)],
             length(data2[,T2][!is.na(data2[,T2])]),
             summary(data2[,T2],digits=8)[c(1,3,6)],
             wilcox.test(data1[,T1],data2[,T2],paired=TRUE)$p.value,
             t.test(data1[,T1],data2[,T2],paired=TRUE)$p.value,
             length(data1[,1][!is.na(data1[,T1]) & !is.na(data2[,T2])])))
    rownames(tbl)<-c(title)
    colnames(tbl)<-c(paste(c("N","Min","Med","Max"),rep(T1,4),sep="."),
                     paste(c("N","Min","Med","Max"),rep(T2,4),sep="."),"Wilcoxon","t","NPairs")
    return(tbl)
  }
}
