#' TCR Scatter Plot Function
#'
#' To generate scatter plot.
#' @param data Data frame of counts of clonotypes.
#' @param time The vector of interested time points or biospecimen samples.
#' @param FC.cutoff Fold change range limit to define the three groups of clonotypes: decrease (FC<-FC.cutoff), increase (FC>FC.cutoff) and unchanged (|FC|<FC.cutoff).
#' @return Generates a plot.

#' @export

plotscatter <- function(data,time,FC.cutoff)
    {
        #browser()
        dt <- data[,time]
        FC <- log2(10^dt[,2]/10^dt[,1])
        dt[is.na(dt[,1]),1] <- -7
        dt[is.na(dt[,2]),2] <- -7
        idx <- FC < -2| FC >2
        plot(dt[!idx,1],dt[!idx,2],xlab=paste("log10(",time[1],")",sep=""),ylab=paste("log10(",time[2],")",sep=""),xlim=c(-7,-0.5),ylim=c(-7, -0.5))
        points(dt[idx,1],dt[idx,2],col="red")
        points(dt[dt[,1]==-7|dt[,2]==-7,1],dt[dt[,1]==-7|dt[,2]==-7,2],col="blue")
    }
