#' TCR Convergent Frequency Function
#'
#' To count repeat V genes and CDR3 regions.
#' 
#' @param dt.wide Data matrix with columns of counts, a column of V gene, and a column of amino acid CDR3 sequence.
#' @param vGene Column name in data matrix with V gene data.
#' @param CDR3.AA Column name in data matrix with CDR3 region data.
#' 
#' @return Convergent frequency.
#' @export

convergent_TCR_frequency.fn <- function(dt.wide=TCRtestdata$subj01,vGene="V_Segment_Major_Gene",CDR3.AA="CDR3_Sense_Sequence")
{
 idx <- grep("Count",names(dt.wide))
 convergent_freq_rt <- NULL
 for (i in idx)
 {
  dt <- dt.wide[,c(vGene,CDR3.AA,names(dt.wide)[i])]
  dt[,"vGene.AA"] <- paste(dt[,vGene],dt[,CDR3.AA],sep="_")
  convergent_count <- aggregate(dt[,grep("Count",names(dt))], by=list(vGene.AA=dt$vGene.AA), FUN=function(x)
  sum(x,na.rm=TRUE))
  convergent_freq <- convergent_count[,2]/sum(convergent_count[,2],na.rm=TRUE)
  convergent_n <- aggregate(dt[,grep("Count",names(dt))], by=list(vGene.AA=dt$vGene.AA), FUN=function(x)
  sum(!is.na(x),na.rm=TRUE))
  convergent_rt <- cbind(convergent_n,convergent_count[,2],convergent_freq)
  colnames(convergent_rt)[-1] <- c("n","Count","Frequency")
  convergent_rt <- convergent_rt[convergent_rt[,"n"]!=0,]
  convergent_freq_rt <- cbind(convergent_freq_rt,
  c(sum(convergent_rt[convergent_rt[,"n"]>1,"Count"]),sum(convergent_rt[convergent_rt[,"n"]>1,"Frequency"])))
 }
 #browser()
 convergent_freq_rt <- as.data.frame(convergent_freq_rt)
 colnames(convergent_freq_rt) <-names(dt.wide)[idx]
 rownames(convergent_freq_rt) <-c("n","convergent_freq")
 return(convergent_freq_rt)
}
