#' TCR Dynamics Function: Binary Similarity Measures
#'
#' To generate binary similarity measures of TCR repertoire across time, including Jaccard, Faith, Mountford, Simpson, and Baroni-Urbani and Buser.
#' @param data List of data frames of TCR repertoire data. Each data frame presents one subject with row corresponding to clonotype and column corresponding to time point.
#' @param time The vector of interested time points or biospecimen samples.
#' @param cutoff Minimum clonotypes count.
#' @return List of 6 matrices; overlap.BUB.1, overlap.BUB.2, overlap.JACCRD, overlap.FAITH, overlap.Mountford, overlap.SIMPSON.
#' @export

binary.similarity <- function(data, time=c("01", "02", "03"), cutoff=0){
### ,cutoff=0
 C1 = paste("Count_", time[1], sep = "")
 C2 = paste("Count_", time[2], sep = "")
 C3 = paste("Count_", time[3], sep = "")

 compare.pair <- matrix(c(C1,C2,C1,C3,C2,C3),byrow=T,nrow=3) ### currently only work for three time points
 overlap.BUB.1<- matrix(NA,nrow=length(data),ncol=3)
 overlap.BUB.2<- matrix(NA,nrow=length(data),ncol=3)
 overlap.JACCRD<- matrix(NA,nrow=length(data),ncol=3)
 overlap.FAITH<- matrix(NA,nrow=length(data),ncol=3)
 overlap.Mountford<- matrix(NA,nrow=length(data),ncol=3)
 overlap.SIMPSON<- matrix(NA,nrow=length(data),ncol=3)

 ID <- names(data)
 for(i in 1:length(data))
 {
  dt <- data[[i]]
  dt.wide <- dt
  if (cutoff > 0)
    {
        for (j in c(C1,C2,C3))
            dt.wide[(!is.na(dt[,j]) & dt[,j]<cutoff),j] <- NA
    }
  if (!(sum(names(dt.wide)==C1)==0 | sum(names(dt.wide)==C2)==0 | sum(names(dt.wide)==C3)==0))
  {
   dt.wide <- dt.wide[!is.na(dt.wide[,C1])|!is.na(dt.wide[,C2])|!is.na(dt.wide[,C3]),]
   for (k in 1:3)
    {
     c <- sum(!is.na(dt.wide[,compare.pair[k,1]]) & is.na(dt.wide[,compare.pair[k,2]]))
     b <- sum(!is.na(dt.wide[,compare.pair[k,2]]) & is.na(dt.wide[,compare.pair[k,1]]))
     a <- sum(!is.na(dt.wide[,compare.pair[k,1]]) & !is.na(dt.wide[,compare.pair[k,2]]))
     d <- sum(is.na(dt.wide[,compare.pair[k,1]]) & is.na(dt.wide[,compare.pair[k,2]]))
     overlap.BUB.1[i,k] <- (sqrt(a)*sqrt(d)+a)/(sqrt(a)*sqrt(d)+a+b+c)
     overlap.BUB.2[i,k] <- (sqrt(a)*sqrt(d)+a-(b+c))/(sqrt(a)*sqrt(d)+a+b+c)
     overlap.JACCRD[i,k] <- a/(a+b+c)
     overlap.FAITH[i,k] <- (a+0.5*d)/(a+b+c+d)
     overlap.Mountford[i,k] <- a/10000/(0.5*(a/10000*b+a/10000*c)+b/10000*c)
     overlap.SIMPSON[i,k] <- a/(min(a+b,a+c))
    }
   }
  }
  if (length(ID) == length(data))
  {
   rownames(overlap.BUB.1) <- ID
   rownames(overlap.BUB.2) <- ID
   rownames(overlap.JACCRD) <- ID
   rownames(overlap.FAITH) <- ID
   rownames(overlap.Mountford) <- ID
   rownames(overlap.SIMPSON) <- ID
  }

 colnames(overlap.BUB.1) <- c(paste(time[1],time[2],sep="_"),paste(time[1],time[3],sep="_"),paste(time[2],time[3],sep="_"))
 colnames(overlap.BUB.2) <- colnames(overlap.BUB.1)
 colnames(overlap.JACCRD) <- colnames(overlap.BUB.1)
 colnames(overlap.FAITH) <- colnames(overlap.BUB.1)
 colnames(overlap.Mountford) <- colnames(overlap.BUB.1)
 colnames(overlap.SIMPSON) <- colnames(overlap.BUB.1)

 return (rt=list(overlap.BUB.1=overlap.BUB.1,
              overlap.BUB.2=overlap.BUB.2,
              overlap.JACCRD=overlap.JACCRD,
              overlap.FAITH=overlap.FAITH,
              overlap.Mountford=overlap.Mountford,
              overlap.SIMPSON=overlap.SIMPSON))
}
