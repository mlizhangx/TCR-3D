The tarball TCR3D_[version].tar.gz contains the R software package TCR3D with all the functions,
example data, and documentation we developed for a T cell receptor repertoire data and analysis
pipeline. To install the package into your R library, extract the file to your computer and just
follow these two easy steps at your R console prompt:
R>setwd("path/to/tarball")
R>install.packages("TCR3D_[version].tar.gz",repos=NULL,type="source")
Then have fun!

Li Zhang and Alan Paciorek
alan.paciorek@ucsf.edu
2019-09-30
