#' TCR Dynamics Function: Proportion of Decrease, Increase and Same Clones Across Time Points
#'
#' To generate summary statistics of the proportions of decrease, increase, and unchanged clonotypes based on fold change in TCR repertoire across time points or biospecimens for a subject.
#' @param data List of data frames of TCR repertoire data. Each data frame presents one subject with row corresponding to clonotype and column corresponding to time point.
#' @param T1 The first interested time point or biospecimen (denominator).
#' @param T2 The second interested time point or biospecimen (numerator).
#' @param overlap Indicator of using clonotypes from both time points (default=TRUE), otherwise including all clonotypes from either.
#' @param cutoff Minimum clonotype count.
#' @param FC.cutoff Fold change range limit to define the three groups of clonotypes: decrease (FC<-FC.cutoff), increase (FC>FC.cutoff) and unchanged (|FC|<FC.cutoff).
#' @return List of 2 matrices for counts and frequencies with 9 columns; FC.mean, FC.sd, n.All, n.I, n.S, n.D, p.I, p.S, p.D.
#' @export

DIS <- function(data, T1 = "01", T2 = "02", overlap=TRUE, cutoff = 0, FC.cutoff=2)
{
 C1 = paste("Count_", T1, sep = "")
 C2 = paste("Count_", T2, sep = "")
 F1 = paste("Frequency_", T1, sep = "")
 F2 = paste("Frequency_", T2, sep = "")

 ID = names(data)
 count.FC.summary <- matrix(NA,nrow=length(data),ncol=6)
 freq.FC.summary <- matrix(NA,nrow=length(data),ncol=6)
 for(i in 1:length(data))
 {
  dt.all <- data[[i]]
  dt.wide <- dt.all
  if (cutoff >0)
  {
   for (j in c(T1,T2))
   {
    Cj = paste("Count_", j, sep = "")
    Fj = paste("Frequency_", j, sep = "")
    dt.wide[!is.na(dt.all[,Cj]) & dt.all[,Cj]<cutoff,Cj] <- NA
    dt.wide[!is.na(dt.all[,Cj]) & dt.all[,Cj]<cutoff,Fj] <- NA
    dt.wide[!is.na(dt.wide[,Cj]),Fj] <- log10(dt.wide[!is.na(dt.wide[,Cj]),Cj]/sum(dt.wide[,Cj],na.rm=TRUE))
   }
  }
  if (!(sum(names(dt.wide)==C1)==0 | sum(names(dt.wide)==C2)==0))
  {
   if (overlap)
   {
    dt.wide <- dt.wide[!is.na(dt.wide[,C1]) & !is.na(dt.wide[,C2]),]
    FC <- log2(dt.wide[,C2]/dt.wide[,C1])
    count.FC.summary[i,] <- c(mean(FC),sd(FC),nrow(dt.wide),sum(FC>=FC.cutoff),sum(FC<FC.cutoff & FC>-FC.cutoff),sum(FC<= -FC.cutoff))
    FC <- log2((10^dt.wide[,F2])/(10^dt.wide[,F1]))
    freq.FC.summary[i,] <- c(mean(FC),sd(FC),nrow(dt.wide),sum(FC>=FC.cutoff),sum(FC<FC.cutoff & FC>-FC.cutoff),sum(FC<= -FC.cutoff))
   }
   else
   {
    dt.wide <- dt.wide[!is.na(dt.wide[,C1]) | !is.na(dt.wide[,C2]),]
    dt.wide[is.na(dt.wide[,C1]),C1] <- 1
    dt.wide[is.na(dt.wide[,C2]),C2] <- 1
    FC <- log2(dt.wide[,C2]/dt.wide[,C1])
    count.FC.summary[i,] <- c(mean(FC),sd(FC),nrow(dt.wide),sum(FC>=FC.cutoff),sum(FC<FC.cutoff & FC>-FC.cutoff),sum(FC<= -FC.cutoff))

    dt.wide[,F1] <- 10^dt.wide[,F1]
    dt.wide[,F2] <- 10^dt.wide[,F2]
    dt.wide[is.na(dt.wide[,F1]),F1] <- 1/sum(dt.wide[,C1],na.rm=TRUE)
    dt.wide[is.na(dt.wide[,F2]),F2] <- 1/sum(dt.wide[,C2],na.rm=TRUE)
    FC <- log2(dt.wide[,F2]/dt.wide[,F1])
    freq.FC.summary[i,] <- c(mean(FC),sd(FC),nrow(dt.wide),sum(FC>=FC.cutoff),sum(FC<FC.cutoff & FC>-FC.cutoff),sum(FC<= -FC.cutoff))
   }
  }
 }
 if(length(ID) == length(data))
 {
  rownames(count.FC.summary) <- ID
  rownames(freq.FC.summary) <- ID
 }


 colnames(count.FC.summary) <- c("FC.mean","FC.sd","n.All","n.I","n.S","n.D")
 count.FC.summary <- cbind(count.FC.summary,count.FC.summary[,c("n.I","n.S","n.D")]/count.FC.summary[,"n.All"])
 colnames(count.FC.summary)[7:9] <- c("p.I","p.S","p.D")

  colnames(freq.FC.summary) <- c("FC.mean","FC.sd","n.All","n.I","n.S","n.D")
  freq.FC.summary <- cbind(freq.FC.summary,freq.FC.summary[,c("n.I","n.S","n.D")]/freq.FC.summary[,"n.All"])
  colnames(freq.FC.summary)[7:9] <- c("p.I","p.S","p.D")

 return(list(count.FC.summary=count.FC.summary, freq.FC.summary=freq.FC.summary))
}
