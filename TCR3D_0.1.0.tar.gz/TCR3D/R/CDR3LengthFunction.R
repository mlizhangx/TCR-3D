#' TCR Dynamics Function: Complementarity Determining Region 3 (CDR3) Length
#'
#' To generate length of TCR repertoire complementarity determining region 3.
#' @param data List of data frames of TCR repertoire data. Each data frame presents one subject with row corresponding to clonotype and column corresponding to time point.
#' @param gene.family Gene family (default is "v_family").
#' @param time The vector of interested time points or biospecimen samples.
#' @param xlab Label for horizontal axis.
#' @param type Type of plot (default="median") bar chart, otherwise boxplot.
#' @return Plots summary statistics of lengths of each gene type for each time point.
#' @export

cdr3length.summary <- function(data,gene.family="v_family",time,xlab, type="median")
    {
        #browser()
        library(ggplot2)
        output.all <- NULL
        for (j in 1:length(time))
            {
                rt <- by(data[!is.na(data[,time[j]]),"cdr3_length"],data[!is.na(data[,time[j]]),gene.family],summary)
                output <- summary(data[!is.na(data[,time[j]]),"cdr3_length"])
                for(i in 1:length(rt)) output=rbind(output,matrix(rt[[i]],ncol=6,byrow=T))
                rownames(output) <- c("All",names(table(data[!is.na(data[,time[j]]),gene.family])))
                output <- cbind(rownames(output),rep(time[j],nrow(output)),as.data.frame(output))
                colnames(output)[1:2] <- c("gene.family","time")
                rownames(output) <- paste(rownames(output),time[j],sep="_")
                output.all <- rbind(output.all,output)
            }
        if (type=="median")
            p <- ggplot(output.all,aes(x = gene.family, y = Median))+geom_bar(stat = "identity")+facet_grid(time~.)+theme(axis.text.x = element_text(angle = 90, hjust = 1))+xlab(xlab)+ylab("Median CDR3 length")
        else
            {
                dt.ggplot <- NULL
                for (j in time)
                    dt.ggplot <- rbind(dt.ggplot,cbind(data[!is.na(data[,i]),c("cdr3_length",gene.family)],rep(j,sum(!is.na(data[,i])))))
                dt.ggplot <- as.data.frame(dt.ggplot)
                colnames(dt.ggplot) <- c("cdr3_length","gene.family","time")
                dt.ggplot[,1] <- as.numeric(as.character(dt.ggplot[,1]))
                p <- ggplot(dt.ggplot,aes(gene.family, cdr3_length))+geom_boxplot()+facet_grid(time~.)+theme(axis.text.x = element_text(angle = 90, hjust = 1))+xlab(xlab)+ylab("CDR3 length")
            }
        return(list(output=output.all,p=p))
    }
