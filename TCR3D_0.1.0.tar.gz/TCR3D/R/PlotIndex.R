#' Diversity and Dynamics Index Plotting Function
#'
#' To plot the diversity or dynamics index of TCR sequencing repertoire across time points.
#' @param data Storing a matrix of a diversity or dynamics index with row standing for subjects and column representing time points or time pairs.
#' @param xlab Horizontal axis label.
#' @param ylab Vertical axis label.
#' @param title Plot title.
#' @param type Boxplot (default="boxplot") or tracking time lines ("line").
#' @return Generates a plot.
#' @import gridExtra
#' @import reshape2
#' @import ggplot2
#' @import plyr
#' @import scales
#' @import latticeExtra
#' @export

plotindex = function(data, xlab = "", ylab = "", title = "",type="boxplot"){
	if (type=="boxplot")
  		df.ggplot = bar.gg(data, xlab, ylab, title)
  	else if (type=="line")
  		df.ggplot = line.gg(data, xlab, ylab, title)
  return(df.ggplot)
}

line.gg = function(data, xlab = "", ylab = "", title = ""){
  data = as.data.frame(data)
  if ("X" %in% colnames(data) == FALSE){
    data$X = rownames(data)
  }
  df.melt = melt(data)
  df.melt <- df.melt[!is.na(df.melt[,"value"]),]
  df.ggplot.line = ggplot(df.melt, aes(x=variable, y=value,group=factor(X),col=factor(X))) +
    geom_line()+geom_point(size=2) +
    ggtitle(title) + xlab(xlab) + ylab(ylab) + theme(legend.position="none") + scale_y_continuous(limits=c(min(df.melt[,"value"],na.rm=T),max(df.melt[,"value"],na.rm=T)))+
    theme(legend.position="none")+
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
          panel.background = element_blank(), axis.line = element_line(colour = "black"))
  return(df.ggplot.line)
}

bar.gg = function(data, xlab = "", ylab = "", title = ""){
  data = as.data.frame(data)
  if ("X" %in% colnames(data) == FALSE){
    data$X = rownames(data)
  }
  df.melt = melt(data)
  df.melt <- df.melt[!is.na(df.melt[,"value"]),]
  ds <- ddply(df.melt, .(variable), summarise, median = median(value, na.rm=TRUE), q1 = quantile(value,na.rm=TRUE)[2], q3 = quantile(value,na.rm=TRUE)[4])
  df.ggplot = ggplot(df.melt, aes(x=variable, y=value)) + geom_point(position = position_jitter(w=0.1), size=1, ) +
    geom_errorbar(data = ds, aes(x =variable, y = median, ymin = q1, ymax = q3),colour = 'black', width = 0.4) +
    geom_errorbar(data =ds, aes(x=variable,y=median, ymin=median,ymax=median), colour = 'black', width = 0.8) +
    ggtitle(title) + xlab(xlab) + ylab(ylab) + theme(legend.position="none") + scale_y_continuous(limits=c(min(df.melt[,"value"],na.rm=T), max(df.melt[,"value"],na.rm=T)))+
    theme(legend.position="none")+
    theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
          panel.background = element_blank(), axis.line = element_line(colour = "black"))
  return(df.ggplot)
}
