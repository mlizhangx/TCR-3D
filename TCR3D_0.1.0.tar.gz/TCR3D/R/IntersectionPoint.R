#' TCR Count Intersection Function
#'
#' To find the value where curves of two samples intersect.
#' @param data Data frame of a single subject with row corresponding to clonotype and column corresponding to time point.
#' @param T1 The first interested time point or biospecimen.
#' @param T2 The second interested time point or biospecimen.
#' @param cutoff Minimum clonotype count.
#' @return Integer.
#' @export

### intersection.point(data=TCRtestdata$subj01,T1="Count_01",T2="Count_02")

intersection.point <- function(data,T1,T2,cutoff=0)
{
	dt.1 <- data[!is.na(data[,T1]) & data[,T1]>=cutoff,T1]
	dt.2 <- data[!is.na(data[,T2]) & data[,T2]>=cutoff,T2]

	dt.1 <- dt.1[order(dt.1,decreasing =TRUE)]
	dt.2 <- dt.2[order(dt.2,decreasing =TRUE)]

	if (length(dt.1)>length(dt.2))
	{
		dt.12.order=dt.1[1:length(dt.2)]
		below=dt.12.order>dt.2
	}
	else
	{
		dt.12.order=dt.2[1:length(dt.1)]
		below=dt.12.order>dt.1
	}
	diff.below=diff(below)
	intersect.point<-which(diff(below)!=0)
	#intersect.point<-intersect.point[intersect.point>10]
	return(dt.12.order[intersect.point[1]])

}
