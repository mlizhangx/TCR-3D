#' TCR Diversity Indices Function
#'
#' To generate diversity indices of TCR repertoire including uniques, read depth, Shannon index, clonality, geometric coefficient of variation, Gini Simpson and inverse Simpson as any other order a of Hill numbers.
#' @param data List of data frames of cleaned TCR repertoire data, one data frame each subject and one or more sets of columns each sequences (time points).
#' @param time Vector of time point.
#' @param a Order of Hill numbers.
#' @param cutoff Minimum clonotype count.
#' @return List of 11 matrices; Uniques, Readdepth Counts, Shannon Frequency, Shannon Counts, Min Freq, Max Freq, Min Count, Max Count, Clonality, GCV, Hill.
#' @importFrom DiversitySampler Hs
#' @export

# #' @param cutoff Mimimum clonotypes count.
# Example:
# dt = list( "03015_01" = P1, "03015_02" = P2, "03015_03" = P3)
# test = TCR.summary(dt, c("00", "01", "02", "03", "04", "05", "06", "07"))

diversity.set <- function(data, time, a=0, cutoff=0){
 ### , cutoff =0
 ##require("DiversitySampler")
 #create Tables:
 unique.summary <- matrix(NA,nrow=length(data),ncol= length(time))
 rownames(unique.summary) <- names(data)
 colnames(unique.summary) <- time
 readdepth.counts <- unique.summary
 shannon.freq <- unique.summary
 shannon.counts <- unique.summary
 Clonality <- unique.summary
 GCV <- unique.summary
 Hill <- unique.summary
 count.min <- unique.summary
 freq.min <- unique.summary
 count.max <- unique.summary
 freq.max <- unique.summary
 #Calculations
 for(i in 1:length(data))
 {
  dt.all <- data[[i]]
  dt.wide <- dt.all
  if (cutoff >0)
	 {
	  for (j in 1:length(time))
	  {
	   Cj = paste("Count_", time[j], sep="")
	   Fj = paste("Frequency_", time[j], sep="")
	   dt.wide[!is.na(dt.all[,Cj]) & dt.all[,Cj]<cutoff,Cj] <- NA
	   dt.wide[!is.na(dt.all[,Fj]) & dt.all[,Fj]<cutoff,Fj] <- NA
	   dt.wide[!is.na(dt.wide[,Cj]),Fj] <- log10(dt.wide[!is.na(dt.wide[,Cj]),Cj]/sum(dt.wide[,Cj],na.rm=TRUE))
  	   }
 	}
    match.ls <- match(paste("Frequency",colnames(unique.summary),sep="_"),colnames(dt.wide))
    match.ls.2 <- match(colnames(dt.wide),paste("Frequency",colnames(unique.summary),sep="_"))
    match.ls.2 <- match.ls.2[!is.na(match.ls.2)]
    match.ls.2 <- match.ls.2[order(match.ls.2)]
    k <- 1
    for (j in match.ls[!is.na(match.ls)])
    {
      unique.summary[i,match.ls.2[k]] <- sum(!is.na(dt.wide[,j]))
      shannon.freq[i,match.ls.2[k]] <- DiversitySampler::Hs(10^(dt.wide[!is.na(dt.wide[,j]),j]))
      freq.min[i,match.ls.2[k]] <- summary(dt.wide[,j])["Min."]
      freq.max[i,match.ls.2[k]] <- summary(dt.wide[,j])["Max."]
      Clonality[i,match.ls.2[k]] <- 1-shannon.freq[i,match.ls.2[k]]/log(unique.summary[i,match.ls.2[k]])
      GCV[i,match.ls.2[k]] <- exp(sd(dt.wide[,j], na.rm = T)*log(10))-1
      Hill[i,match.ls.2[k]] <- exp(log(sum((10^(dt.wide[,j]))^a)/(1-a)))
      k <- k+1
    }
    match.ls <- match(paste("Count",colnames(unique.summary),sep="_"),colnames(dt.wide))
    match.ls.2 <- match(colnames(dt.wide),paste("Count",colnames(unique.summary),sep="_"))
    match.ls.2 <- match.ls.2[!is.na(match.ls.2)]
    match.ls.2 <- match.ls.2[order(match.ls.2)]
    k <- 1
    for (j in match.ls[!is.na(match.ls)])
    {
      readdepth.counts[i,match.ls.2[k]] <- sum(dt.wide[,j],na.rm=TRUE)
      shannon.counts[i,match.ls.2[k]] <- DiversitySampler::Hs(dt.wide[!is.na(dt.wide[,j]),j])
      count.min[i,match.ls.2[k]] <- summary(dt.wide[,j])["Min."]
      count.max[i,match.ls.2[k]] <- summary(dt.wide[,j])["Max."]
      k <- k+1
    }
  }
  return.list = list("Uniques" = unique.summary, "Readdepth Counts" = readdepth.counts,
                     "Shannon Frequency" = shannon.freq, "Shannon Counts" = shannon.counts,
                     "Min Freq" = freq.min, "Max Freq" = freq.max,
                     "Min Count" = count.min, "Max Count" = count.max,
                     "Clonality" = Clonality, "GCV" = GCV,"Hill"=Hill)
  return(return.list)
}
