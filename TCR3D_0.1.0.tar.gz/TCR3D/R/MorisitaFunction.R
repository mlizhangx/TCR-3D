#' TCR Dynamics Function: Morisita's Index
#'
#' To generate summary statistic of Morisita's Index of TCR repertoire across time points.
#' @param data List of data frames of TCR repertoire data. Each data frame presents one subject with row corresponding to clonotype and column corresponding to time point.
#' @param T1 The first interested time point or biospecimen (denominator).
#' @param T2 The second interested time point or biospecimen (numerator).
#' @param cutoff Minimum clonotypes count.
#' @return Matrix with 4 columns; MD.freq.overlap, MD.log10freq.overlap, MD.freq.all, MD.log10freq.all.
#' @export

# Overall Comments for these functions:
# The input data frame, is a list of patient data with each entry corresponding to a different assay.
# The Patient ID is a list of variables that follow in the same order as the input data frame.
# T1 is the string that defines that data, and the same goes for T2.
#
# Examples:
# test = morisita(data, T1 = "02", T2 = "03")

morisita <- function(data, T1 = "01", T2 = "02", cutoff =0){
 #frequency must be log10
 C1 = paste("Count_", T1, sep = "")
 C2 = paste("Count_", T2, sep = "")
 F1 = paste("Frequency_", T1, sep = "")
 F2 = paste("Frequency_", T2, sep = "")

 ID = names(data)

 MD.freq.rt <- matrix(NA,nrow=length(data),ncol=4)

 for(i in 1:length(data))
 {
  dt.all <- data[[i]]
  dt.wide <- dt.all
  if (cutoff >0)
  {
   for (j in c(T1,T2))
   {
    Cj = paste("Count_", j, sep="")
    Fj = paste("Frequency_", j, sep="")
    dt.wide[!is.na(dt.all[,Cj]) & dt.all[,Cj]<cutoff,Cj] <- NA
    dt.wide[!is.na(dt.all[,Cj]) & dt.all[,Cj]<cutoff,Fj] <- NA
    dt.wide[!is.na(dt.wide[,Cj]),Fj] <- log10(dt.wide[!is.na(dt.wide[,Cj]),Cj]/sum(dt.wide[,Cj],na.rm=TRUE))
   }
  }
  if (!(sum(names(dt.wide)==C1)==0 | sum(names(dt.wide)==C2)==0))
  {
   dt.wide <- dt.wide[!is.na(dt.wide[,F1])|!is.na(dt.wide[,F2]),]
   MD.log10freq.overlap <-  morisita.helper(dt.wide[,c(F1,F2)],na.rm=TRUE)
   dt.wide[,F1] <- 10^dt.wide[,F1]
   dt.wide[,F2] <- 10^dt.wide[,F2]
   MD.freq.overlap <-  morisita.helper(dt.wide[,c(F1,F2)],na.rm=TRUE)
   idx.01 <- is.na(dt.wide[,F1])
   idx.02 <- is.na(dt.wide[,F2])
   dt.wide[is.na(dt.wide[,F1]),F1] <- 0
   dt.wide[is.na(dt.wide[,F2]),F2] <- 0
   MD.freq <-  morisita.helper(dt.wide[,c(F1,F2)],na.rm=FALSE)
   dt.wide[idx.01,F1] <- 1/sum(dt.wide[,C1],na.rm=TRUE)
   dt.wide[idx.02,F2] <- 1/sum(dt.wide[,C2],na.rm=TRUE)
   MD.log10freq <-  morisita.helper(log10(dt.wide[,c(F1,F2)]),na.rm=FALSE)
   MD.freq.rt[i,] <- c(MD.freq.overlap,MD.log10freq.overlap,MD.freq,MD.log10freq)
  }
 }

 if (length(ID) == length(data))
 {
  rownames(MD.freq.rt) <- ID
 }

 colnames(MD.freq.rt) <- c("MD.freq.overlap","MD.log10freq.overlap","MD.freq.all","MD.log10freq.all")

 return(MD.freq.rt)
}

# Supporting Function To Morisita's Index Function
# To generate summary statistic Morisita's Index of TCR repertoire dynamics.

morisita.helper <- function(dt,na.rm=na.rm){
  x <- dt[,1]
  y <- dt[,2]
  if (na.rm==TRUE)
  {
    x <- x[(!is.na(dt[,1])) & (!is.na(dt[,2]))]
    y <- y[(!is.na(dt[,1])) & (!is.na(dt[,2]))]
  }
  x.sum <- sum(x)
  y.sum <- sum(y)
  rt <- 2*sum(x*y)/((sum(x^2)/x.sum^2+sum(y^2)/y.sum^2)*x.sum*y.sum)
  return(rt)
}
