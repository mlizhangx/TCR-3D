#' TCR Plot Raw Function
#'
#' To plot ordered counts of clonotypes.
#' @param data Data frame of counts of clonotypes.
#' @param time Vector of column names of counts in source data.
#' @param col Vector of colors for lines.
#' @param main Main plot.
#' @param type Type of plot (default="scatter") otherwise curves.
#' @param log10 Indicator using logarithm base 10 (default=TRUE).
#' @param ylab Label for vertical axis (default="log10(count)").
#' @param cutoff Minimum clonotype count.
#' @return Generates a plot.
#' @export

### plotraw(TCRtestdata$subj01,time=c("Count_01","Count_02","Count_03"),col=c("black","red","green"), main="subject01",cutoff=0)

plotraw <- function(data,time,col, main="",type="scatter",log10=TRUE,ylab="log10(count)",cutoff=0)
{
	if (type=="scatter")
	{
		library(gclus)
		if (log10)
        	dt <- log10(data[,time]) # get data
        else
        	dt <- data[,time]
        cpairs(dt,main=main )
	}
	else
	{
		dt.order <- NULL
		for (i in 1:length(time))
		{
			dt.i <- data[!is.na(data[,time[i]]) & data[,time[i]]>=cutoff,time[i]]
			dt.order <- rbind(dt.order,cbind(dt.i[order(dt.i,decreasing =TRUE)],(1:length(dt.i)),rep(time[i],length(dt.i))))
		}
		colnames(dt.order) <- c("count","ID","time")
		dt.order <- as.data.frame(dt.order)
		if (log10)
			dt.order[,"count"] <- log10(as.numeric(as.character(dt.order[,"count"])))
		else
			dt.order[,"count"] <- as.numeric(as.character(dt.order[,"count"]))
		dt.order[,"ID"] <- as.numeric(as.character(dt.order[,"ID"]))
		plot(dt.order[dt.order[,"time"]==time[1],"ID"],dt.order[dt.order[,"time"]==time[1],"count"],type="l",col=col[1],lwd = 2,
         	xlim=c(0,max(dt.order[,"ID"])),ylim=c(min(dt.order[,"count"]),max(dt.order[,"count"])),
         	xlab="Clones",ylab=ylab,main=main)
		for (i in 2:length(time))
      	{
        	if (sum(dt.order[,"time"]==time[i],na.rm=T)>0)
          	lines(dt.order[dt.order[,"time"]==time[i],"ID"],dt.order[dt.order[,"time"]==time[i],"count"],col=col[i],lwd = 2)
    	}
    	legend("topright",legend=time,lty=1,col=col,text.col=col,bty="n")
    }
}
