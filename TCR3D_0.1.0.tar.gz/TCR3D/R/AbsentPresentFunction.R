#' TCR Dynamics Function: Proportions Of Absent Or Present Clones Across Time Points
#'
#' To generate summary statistics of the proportions of clones absent or present in only one sample of TCR repertoire.
#' @param data List of data frames of TCR repertoire data. Each data frame presents one subject with row corresponding to clonotype and columns corresponding to time point.
#' @param T1 First interested time point or biospecimen.
#' @param T2 Second interested time point or biospecimen.
#' @param cutoff Minimum clonotype count.
#' @return Matrix of 7 columns; n.All, n.Absent, n.Overlap, n.Present, p.Absent, p.Overlap, p.Present.
#' @export

absent.present <- function(data, T1 = "01", T2 = "02", cutoff=0){
  C1 = paste("Count_", T1, sep = "")
  C2 = paste("Count_", T2, sep = "")

 ID = names(data)
  prop.absent.present.summary <- matrix(NA,nrow=length(data),ncol=4)
  for(i in 1:length(data))
  {
    dt.all <- data[[i]]
    dt.wide <- dt.all
    if (cutoff >0)
    {
     for (j in c(C1,C2))
      dt.wide[!is.na(dt.all[,j]) & dt.all[,j]<cutoff,] <-NA
    }
    if (!(sum(names(dt.wide)==C1)==0 | sum(names(dt.wide)==C2)==0))
    {
      dt.wide <- dt.wide[!is.na(dt.wide[,C1]) | !is.na(dt.wide[,C2]),c(C1,C2)]
      prop.absent.present.summary[i,] <- c(nrow(dt.wide),sum(!is.na(dt.wide[,C1]) & is.na(dt.wide[,C2])),
                                           sum(!is.na(dt.wide[,C1]) & !is.na(dt.wide[,C2])),
                                           sum(is.na(dt.wide[,C1]) & !is.na(dt.wide[,C2])))
    }
  }
  if (length(ID) == length(data)){
    rownames(prop.absent.present.summary) <- ID
  }

  colnames(prop.absent.present.summary) <- c("n.All","n.Absent","n.Overlap","n.Present")
  prop.absent.present.summary <- cbind(prop.absent.present.summary,prop.absent.present.summary[,c("n.Absent","n.Overlap","n.Present")]/prop.absent.present.summary[,"n.All"])
  colnames(prop.absent.present.summary)[5:7] <- c("p.Absent","p.Overlap","p.Present")
  return (prop.absent.present.summary)
}
